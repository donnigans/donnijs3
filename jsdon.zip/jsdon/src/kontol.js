const Donnigansmand = require('./command');
const { Message, OpType, Location, Profile } = require('../curve-thrift/line_types');

class LINE extends Donnigansmand {
    constructor() {
        super();
        this.receiverID = '';
        this.messages;
        this.payload;
    }

    get myBot() {
        const bot = ["ub3b7829c6ce02c07bdd79c48329d5286"];
        return bot;
    }

    isAdminOrBot(param) {
        return this.myBot.includes(param);
    }

    getOprationType(operations) {
        for (let key in OpType) {
            if(operations.type == OpType[key]) {
                if(key !== 'NOTIFIED_UPDATE_PROFILE') {
                    //console.info(`[# ${operations.type} ] ${key} `);
                }
            }
        }
    }

    poll(operation) {
        if(operation.type == 25) {
            let message = new Message(operation.message);
            this.receiverID = message.to = (operation.message.to === this.myBot[0]) ? operation.message._from : operation.message.to ;
            Object.assign(message,{ ct: operation.createdTime.toString() });
            this.textMessage(message)
        }
        this.getOprationType(operation);
    }

    command(msg, reply) {
        if(this.messages.text !== null) {
            if(this.messages.text === msg.trim()) {
                if(typeof reply === 'function') {
                    reply();
                    return;
                }
                if(Array.isArray(reply)) {
                    reply.map((v) => {
                        this._sendMessage(this.messages, v);
                    })
                    return;
                }
                return this._sendMessage(this.messages, reply);
            }
        }
    }

    async textMessage(messages) {
        this.messages = messages;
        let payload = (this.messages.text !== null) ? this.messages.text.split(' ').splice(1).join(' ') : '' ;
        let receiver = messages.to;
        let sender = messages.from;

        this.command('berkas', ['╭━━━━━━❉\n┝──────────────────────❉\n┝🔰❉DIKNAS DONI OLENG\n┝──────────────────────❉\n┝🔰hajar // untuk nuke\n┝🔰ledakan // kick dan cancel\n┝🔰duar // cancel dan kick\n┝───────────────❉\n╰━━━━━━❉\n https:line.me/ti/p/~don877 \n ┌П┐ (►˛◄) ┌П┐ \n\n 31.10.2020']);
        this.command('hajar', this.Doniganteng.bind(this));
        this.command('ledakan', this.Kontol.bind(this));
        this.command('duar', this.Kontolpecah.bind(this));

    }

}

module.exports = LINE;