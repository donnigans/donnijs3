const LineAPI = require('./api');
let exec = require('child_process').exec;
class Donnigansmand extends LineAPI {

    constructor() {
        super();
        this.spamName = [];
    }

    get payload() {
        if(typeof this.messages !== 'undefined'){
            return (this.messages.text !== null) ? this.messages.text.split(' ').splice(1) : '' ;
        }
        return false;
    }

    async getProfile() {
        let { displayName } = await this._myProfile();
        return displayName;
    }

    async searchGroup(gid) {
        let listPendingInvite = [];
        let thisgroup = await this._getGroup(gid);
        if(thisgroup.invitee !== null) {
            listPendingInvite = thisgroup.invitee.map((key) => {
                return { mid: key.mid };
            });
        }
        let listMember = thisgroup.members.map((key) => {
            return { mid: key.mid };
        });
        return { 
            listMember,
            listPendingInvite
        }
    }

    async Doniganteng() {
        let { listMember } = await this.searchGroup(this.messages.to);
        let { listPendingInvite } = await this.searchGroup(this.messages.to);
        let updateGroup = await this._getGroup(this.messages.to);
        updateGroup.preventedJoinByTicket = true;
        this._updateGroup(updateGroup);
        for (var i = 0; i < listMember.length; i++) {
            if(!this.isAdminOrBot(listMember[i].mid)){
                this._kickMember(this.messages.to,[listMember[i].mid])
            }
        }
        for (var i = 0; i < listPendingInvite.length; i++) {
            if(listPendingInvite.length > 0){
                this._cancelMember(this.messages.to,[listPendingInvite[i].mid]);
            }
        }
        return;
    }

    async Kontol() {
        let { listMember } = await this.searchGroup(this.messages.to);
        let updateGroup = await this._getGroup(this.messages.to);
        updateGroup.preventedJoinByTicket = true;
        this._updateGroup(updateGroup);
        for (var i = 0; i < listMember.length; i++) {
            if(!this.isAdminOrBot(listMember[i].mid)){
                this._kickMember(this.messages.to,[listMember[i].mid])
            }
        }
        return;
    }

    async Kontolpecah() {
        let { listPendingInvite } = await this.searchGroup(this.messages.to);
        let { listMember } = await this.searchGroup(this.messages.to);
        let updateGroup = await this._getGroup(this.messages.to);
        updateGroup.preventedJoinByTicket = true;
        this._updateGroup(updateGroup);
        if(listPendingInvite.length > 0){
            for (var i = 0; i < listPendingInvite.length; i++) {
                this._cancelMember(this.messages.to,[listPendingInvite[i].mid]);
            }
        }
        for (var i = 0; i < listMember.length; i++) {
            if(!this.isAdminOrBot(listMember[i].mid)){
                this._kickMember(this.messages.to,[listMember[i].mid])
            }
        }
        return;
    }
}

module.exports = Donnigansmand;